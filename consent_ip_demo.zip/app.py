import logging
import os
from datetime import datetime, timezone
from flask import Flask, request, render_template_string, make_response

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("consent-demo")

PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Visitor IP Demo</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 650px; margin: 12vh auto;
           padding: 24px; line-height: 1.5; background: #f5f6fa; color: #202433; }
    main { background: white; padding: 28px; border-radius: 16px; box-shadow: 0 8px 30px #0001; }
    button { padding: 12px 18px; border: 0; border-radius: 8px; background: #2459d3;
             color: white; font-size: 16px; cursor: pointer; }
    #result { margin-top: 18px; font-weight: 600; }
  </style>
</head>
<body><main>
  <h1>Visitor IP learning demo</h1>
  <p>This educational demo will send your public IP address and the time of your visit
     to the site operator if you choose to agree.</p>
  <p>Your IP address can reveal approximate network/location information. Do not continue
     unless you understand and agree.</p>
  <button id="agree">I agree to share my IP for this demo</button>
  <p id="result" role="status"></p>
</main>
<script>
document.getElementById("agree").addEventListener("click", async () => {
  const button = document.getElementById("agree");
  const result = document.getElementById("result");
  button.disabled = true;
  result.textContent = "Recording your consent…";
  try {
    const response = await fetch("/consent", {method: "POST"});
    result.textContent = response.ok
      ? await response.text()
      : "Sorry, the request could not be completed.";
  } catch {
    result.textContent = "Connection error. Please try again later.";
    button.disabled = false;
  }
});
</script>
</body></html>
"""

@app.get("/")
def home():
    return render_template_string(PAGE)

@app.post("/consent")
def consent():
    # Render and similar hosts sit behind a proxy. REMOTE_ADDR is the
    # address provided by the hosting platform's trusted proxy layer.
    visitor_ip = request.remote_addr or "unavailable"
    timestamp = datetime.now(timezone.utc).isoformat()
    logger.info("CONSENT_GIVEN timestamp=%s ip=%s", timestamp, visitor_ip)
    return make_response("Thank you. Your consent was recorded.", 200)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)
