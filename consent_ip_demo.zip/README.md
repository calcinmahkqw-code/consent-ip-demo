# Consent-based IP learning demo

This is a small educational website. It records a visitor's IP address in the
hosting service's application logs **only after** the visitor clicks the
explicit consent button.

## Publish on Render

1. Create a GitHub account if you do not already have one.
2. Create a new GitHub repository and upload `app.py`, `requirements.txt`,
   and `render.yaml` from this folder.
3. In Render, choose **New + → Blueprint**, connect that GitHub repository,
   and deploy the blueprint.
4. Render will provide a public HTTPS URL.

## View consent records

In Render, open your web service and select **Logs**. Search for
`CONSENT_GIVEN`. Each record includes the UTC timestamp and IP address.

## Important limitations

- This demo does not collect anything on a Discord image attachment itself.
  Share the public website URL alongside your image; the visitor must open
  the link and click the consent button.
- Hosting logs may be retained according to the hosting provider's policies.
- Do not use this to identify, locate, harass, or track people. Tell visitors
  what is collected and why, and delete records when no longer needed.
- The free hosting tier and log retention policies can change.
